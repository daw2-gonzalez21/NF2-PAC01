<html>
 <head>
  <title>Quieres saber como me llamo.></title>
 </head>
 <body>
     <h2>Lista de 10 conceptos importantes:</h2>
     <ul>
         <li>$_POST</li>
         <li>$_GET</li>
         <li>$_SESSION</li>
         <li>FUNCION DATE()</li>
         <li>CONTROL NULL</li>
         <li>OPERADORES</li>
         <li>URLENCODE</li>
         <li>CODENVY</li>
         <li>PUSH TO GITHUB</li>
         <li>LOGIN</li>
     </ul>
     <p>Califica el documento: 5</p>
     <p>Califica la explicación del profesor: 7</p>
     <p>He mejorado en la programacion web con php y he estado bastantes horas haciendo esto 
        pese a que al final no he logrado poner la cookie y el urlencode no me va.
     </p>
 </body>
</html>