<html>
 <head>
  <title>Comentarios</title>
 </head>
 <body>
     <h2>Lista de 10 conceptos importantes:</h2>
     <ul>
         <li>Estructuras</li>
         <li>IF</li>
         <li>Contador de visitas</li>
         <li>CSS inline</li>
         <li>Funcion date</li>
         <li>Codenvy</li>
         <li>INCLUDE</li>
         <li>mailto:</li>
         <li>PUSH TO GITHUB</li>
         <li>forms</li>
     </ul>
     <p>Califica el documento: 6</p>
     <p>Califica la explicación del profesor: 8</p>
     <p>Los 3 primeros ejercicios los hice relativamente facil, pero a partir del 4 tardé muchas
        horas en saber las cosas y hubo dias que desistí. El documento tampoco ayudaba muchisimo
        aunque en internet invirtiendo horas puedes conseguir toda la información.
     </p>
 </body>
</html>