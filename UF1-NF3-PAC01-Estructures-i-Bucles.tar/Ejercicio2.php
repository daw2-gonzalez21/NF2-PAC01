<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <p>
            <?php

            ?>
        </p>
        <div>
    <footer style="bottom: 0;display: inline-block;position: absolute;margin-left:100px;">
        <p>Site developed by: <a href="mailto:gonzalezballanoraul@fpllefia.com">gonzalezballanoraul@fpllefia.com</a></p>
    </footer>
    </body>
</html>